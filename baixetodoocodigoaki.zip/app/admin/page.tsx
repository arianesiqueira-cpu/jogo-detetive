"use client"

import { useState, useEffect, useRef } from "react"
import { ArrowLeft, Plus, Pencil, Trash2, Download, Upload, RotateCcw, Save, X, Check, AlertCircle } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import {
  getQuestions,
  addQuestion,
  updateQuestion,
  deleteQuestion,
  resetQuestions,
  exportQuestions,
  importQuestions,
  type Question
} from "@/lib/game-data"

export default function AdminPage() {
  const [questions, setQuestions] = useState<Question[]>([])
  const [editingId, setEditingId] = useState<string | null>(null)
  const [isAdding, setIsAdding] = useState(false)
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" } | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const [formData, setFormData] = useState({
    title: "",
    content: "",
    image: "",
    isFake: true,
    explanation: ""
  })

  useEffect(() => {
    setQuestions(getQuestions())
  }, [])

  const showToast = (message: string, type: "success" | "error") => {
    setToast({ message, type })
    setTimeout(() => setToast(null), 3000)
  }

  const refreshQuestions = () => {
    setQuestions(getQuestions())
  }

  const handleAdd = () => {
    setIsAdding(true)
    setEditingId(null)
    setFormData({
      title: "",
      content: "",
      image: "",
      isFake: true,
      explanation: ""
    })
  }

  const handleEdit = (question: Question) => {
    setEditingId(question.id)
    setIsAdding(false)
    setFormData({
      title: question.title,
      content: question.content,
      image: question.image || "",
      isFake: question.isFake,
      explanation: question.explanation
    })
  }

  const handleSave = () => {
    if (!formData.title || !formData.content || !formData.explanation) {
      showToast("Preencha todos os campos obrigatórios!", "error")
      return
    }

    if (isAdding) {
      addQuestion(formData)
      showToast("Pergunta adicionada com sucesso!", "success")
    } else if (editingId) {
      updateQuestion(editingId, formData)
      showToast("Pergunta atualizada com sucesso!", "success")
    }

    setIsAdding(false)
    setEditingId(null)
    refreshQuestions()
  }

  const handleDelete = (id: string) => {
    if (confirm("Tem certeza que deseja excluir esta pergunta?")) {
      deleteQuestion(id)
      refreshQuestions()
      showToast("Pergunta excluída com sucesso!", "success")
    }
  }

  const handleReset = () => {
    if (confirm("Tem certeza? Isso irá restaurar todas as perguntas para o padrão original.")) {
      resetQuestions()
      refreshQuestions()
      showToast("Perguntas restauradas com sucesso!", "success")
    }
  }

  const handleExport = () => {
    const json = exportQuestions()
    const blob = new Blob([json], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = "perguntas-detetive.json"
    a.click()
    URL.revokeObjectURL(url)
    showToast("Perguntas exportadas com sucesso!", "success")
  }

  const handleImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    const reader = new FileReader()
    reader.onload = (event) => {
      const content = event.target?.result as string
      if (importQuestions(content)) {
        refreshQuestions()
        showToast("Perguntas importadas com sucesso!", "success")
      } else {
        showToast("Erro ao importar. Verifique o arquivo JSON.", "error")
      }
    }
    reader.readAsText(file)
    e.target.value = ""
  }

  const handleCancel = () => {
    setIsAdding(false)
    setEditingId(null)
  }

  return (
    <div className="min-h-screen bg-slate-900 p-4 md:p-8">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 flex items-center gap-2 px-4 py-3 rounded-xl shadow-lg animate-slide-down ${
          toast.type === "success" ? "bg-green-500 text-white" : "bg-red-500 text-white"
        }`}>
          {toast.type === "success" ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          {toast.message}
        </div>
      )}

      <div className="max-w-4xl mx-auto space-y-6">
        {/* Cabeçalho */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="outline" size="icon" className="border-slate-700 text-slate-300 hover:bg-slate-800">
                <ArrowLeft className="w-5 h-5" />
              </Button>
            </Link>
            <div>
              <h1 className="text-2xl font-bold text-white">Painel Administrativo</h1>
              <p className="text-slate-400">Gerencie as perguntas do jogo</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            <Button 
              onClick={handleAdd}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          </div>
        </div>

        {/* Ações Globais */}
        <div className="flex flex-wrap gap-2 bg-slate-800/50 rounded-2xl p-4 border border-slate-700">
          <Button 
            onClick={handleExport}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <Download className="w-4 h-4 mr-2" />
            Exportar JSON
          </Button>
          <Button 
            onClick={() => fileInputRef.current?.click()}
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-700"
          >
            <Upload className="w-4 h-4 mr-2" />
            Importar JSON
          </Button>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleImport} 
            accept=".json" 
            className="hidden" 
          />
          <Button 
            onClick={handleReset}
            variant="outline"
            className="border-red-600/50 text-red-400 hover:bg-red-500/10"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Resetar Dados
          </Button>
        </div>

        {/* Formulário de Adição/Edição */}
        {(isAdding || editingId) && (
          <div className="bg-slate-800 rounded-2xl p-6 border border-slate-700 space-y-4 animate-slide-down">
            <h2 className="text-xl font-semibold text-white">
              {isAdding ? "Nova Pergunta" : "Editar Pergunta"}
            </h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Título *
                </label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Ex: Chocolate cura gripe!"
                  className="bg-slate-900 border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Conteúdo da Notícia *
                </label>
                <Textarea
                  value={formData.content}
                  onChange={(e) => setFormData({ ...formData, content: e.target.value })}
                  placeholder="Descreva a notícia..."
                  rows={3}
                  className="bg-slate-900 border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  URL da Imagem (opcional)
                </label>
                <Input
                  value={formData.image}
                  onChange={(e) => setFormData({ ...formData, image: e.target.value })}
                  placeholder="https://exemplo.com/imagem.jpg"
                  className="bg-slate-900 border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Tipo de Notícia *
                </label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={formData.isFake}
                      onChange={() => setFormData({ ...formData, isFake: true })}
                      className="w-4 h-4 text-red-500"
                    />
                    <span className="text-red-400">Fake News</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      checked={!formData.isFake}
                      onChange={() => setFormData({ ...formData, isFake: false })}
                      className="w-4 h-4 text-green-500"
                    />
                    <span className="text-green-400">Verdadeira</span>
                  </label>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-300 mb-2">
                  Explicação Educativa *
                </label>
                <Textarea
                  value={formData.explanation}
                  onChange={(e) => setFormData({ ...formData, explanation: e.target.value })}
                  placeholder="Explique por que a notícia é verdadeira ou falsa..."
                  rows={3}
                  className="bg-slate-900 border-slate-700 text-white"
                />
              </div>

              <div className="flex gap-3">
                <Button 
                  onClick={handleSave}
                  className="bg-green-600 hover:bg-green-700 text-white"
                >
                  <Save className="w-4 h-4 mr-2" />
                  Salvar
                </Button>
                <Button 
                  onClick={handleCancel}
                  variant="outline"
                  className="border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <X className="w-4 h-4 mr-2" />
                  Cancelar
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Lista de Perguntas */}
        <div className="space-y-4">
          <h2 className="text-lg font-semibold text-white">
            Perguntas ({questions.length})
          </h2>
          
          {questions.length === 0 ? (
            <div className="bg-slate-800 rounded-2xl p-8 border border-slate-700 text-center">
              <p className="text-slate-400">Nenhuma pergunta cadastrada.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {questions.map((question, index) => (
                <div
                  key={question.id}
                  className="bg-slate-800 rounded-2xl p-5 border border-slate-700 hover:border-slate-600 transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm text-slate-500">#{index + 1}</span>
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                          question.isFake 
                            ? 'bg-red-500/20 text-red-400' 
                            : 'bg-green-500/20 text-green-400'
                        }`}>
                          {question.isFake ? 'Fake News' : 'Verdade'}
                        </span>
                      </div>
                      <h3 className="text-lg font-semibold text-white truncate">
                        {question.title}
                      </h3>
                      <p className="text-slate-400 text-sm mt-1 line-clamp-2">
                        {question.content}
                      </p>
                    </div>
                    
                    <div className="flex gap-2 flex-shrink-0">
                      <Button
                        onClick={() => handleEdit(question)}
                        size="icon"
                        variant="outline"
                        className="border-slate-600 text-slate-300 hover:bg-slate-700"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => handleDelete(question.id)}
                        size="icon"
                        variant="outline"
                        className="border-red-600/50 text-red-400 hover:bg-red-500/10"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
