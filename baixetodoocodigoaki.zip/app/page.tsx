"use client"

import dynamic from "next/dynamic"

const GameScene = dynamic(
  () => import("@/components/game-3d/game-scene").then(mod => ({ default: mod.GameScene })),
  { 
    ssr: false,
    loading: () => (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-white font-semibold">Carregando jogo 3D...</p>
        </div>
      </div>
    )
  }
)

export default function Home() {
  return <GameScene />
}
