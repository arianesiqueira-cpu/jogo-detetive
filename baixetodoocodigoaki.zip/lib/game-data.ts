export interface Question {
  id: string
  title: string
  content: string
  image?: string
  isFake: boolean
  explanation: string
}

export const initialQuestions: Question[] = [
  {
    id: "1",
    title: "Chocolate cura gripe!",
    content: "Cientistas descobriram que comer 5 barras de chocolate por dia cura qualquer gripe em 24 horas. O estudo foi feito por uma fábrica de chocolates.",
    isFake: true,
    explanation: "Essa notícia é FALSA! Chocolate é gostoso, mas não cura gripe. Sempre desconfie quando a pesquisa é feita pela própria empresa que vende o produto."
  },
  {
    id: "2",
    title: "Vacinas protegem contra doenças",
    content: "A Organização Mundial da Saúde confirma que vacinas são seguras e eficazes para prevenir várias doenças graves como sarampo, poliomielite e gripe.",
    isFake: false,
    explanation: "Essa notícia é VERDADEIRA! Vacinas são comprovadas cientificamente e salvam milhões de vidas todos os anos. Sempre confie em fontes oficiais de saúde."
  },
  {
    id: "3",
    title: "Celular explode se carregar à noite",
    content: "URGENTE: Carregar o celular durante a noite faz ele explodir! Já aconteceu com milhares de pessoas! Compartilhe antes que seja tarde!",
    isFake: true,
    explanation: "Essa notícia é FALSA! Celulares modernos têm sistemas de proteção. Desconfie de mensagens com palavras como 'URGENTE' e 'Compartilhe'."
  },
  {
    id: "4",
    title: "Água é importante para a saúde",
    content: "Médicos recomendam beber cerca de 2 litros de água por dia para manter o corpo saudável e hidratado, especialmente em dias quentes.",
    isFake: false,
    explanation: "Essa notícia é VERDADEIRA! Beber água é essencial para nossa saúde. Essa é uma recomendação médica comprovada."
  },
  {
    id: "5",
    title: "Alienígenas construíram as pirâmides",
    content: "Novo documentário prova que alienígenas construíram as pirâmides do Egito! As pedras eram muito pesadas para humanos carregarem!",
    isFake: true,
    explanation: "Essa notícia é FALSA! Arqueólogos já descobriram como os egípcios construíram as pirâmides usando rampas e muitos trabalhadores. Documentários nem sempre mostram a verdade."
  },
  {
    id: "6",
    title: "Exercícios fazem bem ao corpo",
    content: "Estudos científicos publicados em revistas médicas confirmam que praticar exercícios físicos regularmente melhora a saúde do coração e do cérebro.",
    isFake: false,
    explanation: "Essa notícia é VERDADEIRA! Exercícios são muito importantes para a saúde. Essa informação vem de estudos científicos sérios."
  },
  {
    id: "7",
    title: "Beber refrigerante te dá superpoderes",
    content: "Criança bebe 10 latas de refrigerante e começa a voar! Vídeo viraliza nas redes sociais e já tem 1 milhão de compartilhamentos!",
    isFake: true,
    explanation: "Essa notícia é FALSA! Ninguém ganha superpoderes bebendo refrigerante. Sempre desconfie de notícias muito absurdas, mesmo que tenham muitos compartilhamentos."
  },
  {
    id: "8",
    title: "Ler livros ajuda o cérebro",
    content: "Pesquisadores da Universidade de Harvard descobriram que ler livros regularmente melhora a memória e a capacidade de concentração.",
    isFake: false,
    explanation: "Essa notícia é VERDADEIRA! A leitura realmente estimula o cérebro e melhora várias habilidades mentais. Isso é comprovado por várias pesquisas."
  }
]

const STORAGE_KEY = "detective-game-questions"
const PROGRESS_KEY = "detective-game-progress"
const SCORE_KEY = "detective-game-score"

export function getQuestions(): Question[] {
  if (typeof window === "undefined") return initialQuestions
  
  const stored = localStorage.getItem(STORAGE_KEY)
  if (stored) {
    try {
      return JSON.parse(stored)
    } catch {
      return initialQuestions
    }
  }
  
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initialQuestions))
  return initialQuestions
}

export function saveQuestions(questions: Question[]): void {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(questions))
}

export function addQuestion(question: Omit<Question, "id">): Question {
  const questions = getQuestions()
  const newQuestion: Question = {
    ...question,
    id: Date.now().toString()
  }
  questions.push(newQuestion)
  saveQuestions(questions)
  return newQuestion
}

export function updateQuestion(id: string, updates: Partial<Question>): void {
  const questions = getQuestions()
  const index = questions.findIndex(q => q.id === id)
  if (index !== -1) {
    questions[index] = { ...questions[index], ...updates }
    saveQuestions(questions)
  }
}

export function deleteQuestion(id: string): void {
  const questions = getQuestions()
  const filtered = questions.filter(q => q.id !== id)
  saveQuestions(filtered)
}

export function resetQuestions(): void {
  if (typeof window === "undefined") return
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initialQuestions))
}

export function exportQuestions(): string {
  const questions = getQuestions()
  return JSON.stringify(questions, null, 2)
}

export function importQuestions(json: string): boolean {
  try {
    const questions = JSON.parse(json)
    if (Array.isArray(questions)) {
      saveQuestions(questions)
      return true
    }
    return false
  } catch {
    return false
  }
}

export function getProgress(): number {
  if (typeof window === "undefined") return 0
  return parseInt(localStorage.getItem(PROGRESS_KEY) || "0", 10)
}

export function saveProgress(progress: number): void {
  if (typeof window === "undefined") return
  localStorage.setItem(PROGRESS_KEY, progress.toString())
}

export function getScore(): number {
  if (typeof window === "undefined") return 0
  return parseInt(localStorage.getItem(SCORE_KEY) || "0", 10)
}

export function saveScore(score: number): void {
  if (typeof window === "undefined") return
  localStorage.setItem(SCORE_KEY, score.toString())
}

export function resetGameProgress(): void {
  if (typeof window === "undefined") return
  localStorage.removeItem(PROGRESS_KEY)
  localStorage.removeItem(SCORE_KEY)
}
