"use client"

import { Star, Target, Keyboard, MousePointer } from "lucide-react"

interface GameHUDProps {
  score: number
  totalClues: number
  completedClues: number
  activeClueId: string | null
  showControls: boolean
}

export function GameHUD({ score, totalClues, completedClues, activeClueId, showControls }: GameHUDProps) {
  const progress = totalClues > 0 ? (completedClues / totalClues) * 100 : 0
  
  return (
    <>
      {/* Top bar */}
      <div className="absolute top-4 left-4 right-4 flex items-start justify-between pointer-events-none">
        {/* Score */}
        <div className="bg-slate-900/90 backdrop-blur-sm rounded-lg px-4 py-2 border border-slate-700">
          <div className="flex items-center gap-2">
            <Star className="w-5 h-5 text-yellow-400" />
            <span className="text-white font-bold">{score}</span>
            <span className="text-slate-400 text-sm">pontos</span>
          </div>
        </div>
        
        {/* Progress */}
        <div className="bg-slate-900/90 backdrop-blur-sm rounded-lg px-4 py-2 border border-slate-700">
          <div className="flex items-center gap-3">
            <Target className="w-5 h-5 text-green-400" />
            <div className="flex flex-col">
              <span className="text-white text-sm font-medium">{completedClues}/{totalClues} pistas</span>
              <div className="w-24 h-1.5 bg-slate-700 rounded-full mt-1 overflow-hidden">
                <div 
                  className="h-full bg-green-500 rounded-full transition-all duration-500"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Interaction prompt */}
      {activeClueId && showControls && (
        <div className="absolute bottom-24 left-1/2 -translate-x-1/2 bg-green-600/90 backdrop-blur-sm rounded-lg px-6 py-3 border border-green-500 animate-pulse">
          <div className="flex items-center gap-2">
            <kbd className="bg-white text-green-800 font-bold px-2 py-0.5 rounded text-sm">E</kbd>
            <span className="text-white font-medium">Investigar pista</span>
          </div>
        </div>
      )}
      
      {/* Controls hint */}
      {showControls && (
        <div className="absolute bottom-4 left-4 bg-slate-900/80 backdrop-blur-sm rounded-lg px-4 py-3 border border-slate-700">
          <div className="flex flex-col gap-2 text-sm">
            <div className="flex items-center gap-2 text-slate-300">
              <Keyboard className="w-4 h-4 text-blue-400" />
              <span><kbd className="bg-slate-700 px-1.5 rounded text-xs">W</kbd> <kbd className="bg-slate-700 px-1.5 rounded text-xs">A</kbd> <kbd className="bg-slate-700 px-1.5 rounded text-xs">S</kbd> <kbd className="bg-slate-700 px-1.5 rounded text-xs">D</kbd> mover</span>
            </div>
            <div className="flex items-center gap-2 text-slate-300">
              <MousePointer className="w-4 h-4 text-yellow-400" />
              <span><kbd className="bg-slate-700 px-1.5 rounded text-xs">E</kbd> investigar</span>
            </div>
          </div>
        </div>
      )}
    </>
  )
}
