"use client"

import { Search, Keyboard, Target, Star, Play } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface StartScreen3DProps {
  onStart: () => void
}

export function StartScreen3D({ onStart }: StartScreen3DProps) {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Logo and title */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-green-500/20 mb-6 animate-bounce-slow">
            <Search className="w-12 h-12 text-green-400" />
          </div>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-3">
            Detetive da Verdade
          </h1>
          <p className="text-xl text-green-400 font-semibold">
            Edição 3D
          </p>
        </div>
        
        {/* Description */}
        <Card className="bg-slate-800/50 border-slate-700 p-6 mb-8 animate-slide-up">
          <p className="text-slate-300 text-center leading-relaxed">
            Explore o escritório do detetive em 3D e encontre as pistas espalhadas pelo cenário. 
            Cada pista contém uma notícia que você precisa investigar para descobrir se é 
            <span className="text-green-400 font-semibold"> verdade </span> 
            ou 
            <span className="text-red-400 font-semibold"> fake news</span>!
          </p>
        </Card>
        
        {/* Instructions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-slate-800/50 border-slate-700 p-4 animate-slide-up" style={{ animationDelay: "0.1s" }}>
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-blue-500/20 flex items-center justify-center mb-3">
                <Keyboard className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="font-semibold text-white mb-1">Mover</h3>
              <p className="text-xs text-slate-400">WASD ou setas para andar</p>
            </div>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700 p-4 animate-slide-up" style={{ animationDelay: "0.2s" }}>
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-yellow-500/20 flex items-center justify-center mb-3">
                <Target className="w-6 h-6 text-yellow-400" />
              </div>
              <h3 className="font-semibold text-white mb-1">Investigar</h3>
              <p className="text-xs text-slate-400">Pressione E perto das pistas</p>
            </div>
          </Card>
          
          <Card className="bg-slate-800/50 border-slate-700 p-4 animate-slide-up" style={{ animationDelay: "0.3s" }}>
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-green-500/20 flex items-center justify-center mb-3">
                <Star className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="font-semibold text-white mb-1">Pontuar</h3>
              <p className="text-xs text-slate-400">Ganhe pontos acertando</p>
            </div>
          </Card>
        </div>
        
        {/* Start button */}
        <div className="text-center animate-slide-up" style={{ animationDelay: "0.4s" }}>
          <Button
            onClick={onStart}
            size="lg"
            className="bg-green-600 hover:bg-green-500 text-white font-bold text-lg px-12 py-6 h-auto rounded-xl transition-all hover:scale-105 animate-pulse-slow"
          >
            <Play className="w-6 h-6 mr-2" />
            Iniciar Investigação
          </Button>
          
          <p className="text-xs text-slate-500 mt-4">
            Clique em qualquer lugar da tela para começar e use o teclado para jogar
          </p>
        </div>
      </div>
    </div>
  )
}
