"use client"

import { useRef, useEffect, useState, useCallback } from "react"
import { useFrame, useThree } from "@react-three/fiber"
import { RoundedBox, Sphere } from "@react-three/drei"
import * as THREE from "three"
import type { ClueObject } from "./game-scene"

interface PlayerControllerProps {
  onNearClue: (clueId: string | null) => void
  clues: ClueObject[]
  enabled: boolean
}

export function PlayerController({ onNearClue, clues, enabled }: PlayerControllerProps) {
  const playerRef = useRef<THREE.Group>(null)
  const { camera } = useThree()
  
  const keysRef = useRef({
    forward: false,
    backward: false,
    left: false,
    right: false,
  })
  
  const playerPosition = useRef(new THREE.Vector3(0, 0, 3))
  const playerRotation = useRef(0)
  const bobTime = useRef(0)
  const lastNearClue = useRef<string | null>(null)
  
  const SPEED = 4
  const ROTATION_SPEED = 2.5
  const INTERACTION_DISTANCE = 2.0
  
  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!enabled) return
      switch (e.code) {
        case "KeyW":
        case "ArrowUp":
          keysRef.current.forward = true
          break
        case "KeyS":
        case "ArrowDown":
          keysRef.current.backward = true
          break
        case "KeyA":
        case "ArrowLeft":
          keysRef.current.left = true
          break
        case "KeyD":
        case "ArrowRight":
          keysRef.current.right = true
          break
      }
    }
    
    const handleKeyUp = (e: KeyboardEvent) => {
      switch (e.code) {
        case "KeyW":
        case "ArrowUp":
          keysRef.current.forward = false
          break
        case "KeyS":
        case "ArrowDown":
          keysRef.current.backward = false
          break
        case "KeyA":
        case "ArrowLeft":
          keysRef.current.left = false
          break
        case "KeyD":
        case "ArrowRight":
          keysRef.current.right = false
          break
      }
    }
    
    window.addEventListener("keydown", handleKeyDown)
    window.addEventListener("keyup", handleKeyUp)
    
    return () => {
      window.removeEventListener("keydown", handleKeyDown)
      window.removeEventListener("keyup", handleKeyUp)
    }
  }, [enabled])
  
  useFrame((_, delta) => {
    if (!playerRef.current || !enabled) return
    
    const keys = keysRef.current
    
    // Rotation
    if (keys.left) {
      playerRotation.current += ROTATION_SPEED * delta
    }
    if (keys.right) {
      playerRotation.current -= ROTATION_SPEED * delta
    }
    
    // Movement
    const direction = new THREE.Vector3()
    
    if (keys.forward) {
      direction.z -= 1
    }
    if (keys.backward) {
      direction.z += 1
    }
    
    const isMoving = direction.length() > 0
    
    if (isMoving) {
      direction.normalize()
      direction.applyAxisAngle(new THREE.Vector3(0, 1, 0), playerRotation.current)
      
      const newPos = playerPosition.current.clone()
      newPos.x += direction.x * SPEED * delta
      newPos.z += direction.z * SPEED * delta
      
      // Boundary limits
      newPos.x = Math.max(-8.5, Math.min(8.5, newPos.x))
      newPos.z = Math.max(-8.5, Math.min(8.5, newPos.z))
      
      playerPosition.current.copy(newPos)
      
      // Walking animation
      bobTime.current += delta * 10
    }
    
    // Update player position
    playerRef.current.position.copy(playerPosition.current)
    playerRef.current.rotation.y = playerRotation.current
    
    // Bob effect when walking
    const bobOffset = isMoving ? Math.sin(bobTime.current) * 0.05 : 0
    playerRef.current.position.y = bobOffset
    
    // Update camera (third person)
    const cameraOffset = new THREE.Vector3(0, 3.5, 5)
    cameraOffset.applyAxisAngle(new THREE.Vector3(0, 1, 0), playerRotation.current)
    
    const targetCameraPos = playerPosition.current.clone().add(cameraOffset)
    camera.position.lerp(targetCameraPos, 0.08)
    
    const lookAtPos = playerPosition.current.clone()
    lookAtPos.y += 0.8
    camera.lookAt(lookAtPos)
    
    // Check proximity to clues
    let nearestClueId: string | null = null
    let nearestDistance = INTERACTION_DISTANCE
    
    for (const clue of clues) {
      const cluePos = new THREE.Vector3(...clue.position)
      const distance = playerPosition.current.distanceTo(cluePos)
      
      if (distance < nearestDistance) {
        nearestDistance = distance
        nearestClueId = clue.id
      }
    }
    
    // Only call callback when value changes
    if (nearestClueId !== lastNearClue.current) {
      lastNearClue.current = nearestClueId
      onNearClue(nearestClueId)
    }
  })
  
  return (
    <group ref={playerRef}>
      {/* Detective body */}
      <group>
        {/* Body */}
        <RoundedBox args={[0.5, 0.8, 0.35]} radius={0.08} position={[0, 0.9, 0]} castShadow>
          <meshStandardMaterial color="#1e3a5f" />
        </RoundedBox>
        
        {/* Head */}
        <Sphere args={[0.22, 12, 12]} position={[0, 1.55, 0]} castShadow>
          <meshStandardMaterial color="#fcd5b8" />
        </Sphere>
        
        {/* Detective hat */}
        <group position={[0, 1.82, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.3, 0.3, 0.04, 12]} />
            <meshStandardMaterial color="#2d2d2d" />
          </mesh>
          <mesh position={[0, 0.12, 0]} castShadow>
            <cylinderGeometry args={[0.18, 0.22, 0.22, 12]} />
            <meshStandardMaterial color="#2d2d2d" />
          </mesh>
        </group>
        
        {/* Arms */}
        <RoundedBox args={[0.15, 0.5, 0.15]} radius={0.04} position={[-0.38, 0.9, 0]} castShadow>
          <meshStandardMaterial color="#1e3a5f" />
        </RoundedBox>
        <RoundedBox args={[0.15, 0.5, 0.15]} radius={0.04} position={[0.38, 0.9, 0]} castShadow>
          <meshStandardMaterial color="#1e3a5f" />
        </RoundedBox>
        
        {/* Legs */}
        <RoundedBox args={[0.15, 0.5, 0.15]} radius={0.04} position={[-0.12, 0.25, 0]} castShadow>
          <meshStandardMaterial color="#374151" />
        </RoundedBox>
        <RoundedBox args={[0.15, 0.5, 0.15]} radius={0.04} position={[0.12, 0.25, 0]} castShadow>
          <meshStandardMaterial color="#374151" />
        </RoundedBox>
        
        {/* Magnifying glass */}
        <group position={[0.45, 1.05, 0.2]} rotation={[0, 0, -0.3]}>
          <mesh>
            <torusGeometry args={[0.1, 0.015, 6, 12]} />
            <meshStandardMaterial color="#fbbf24" metalness={0.7} />
          </mesh>
          <mesh position={[0, -0.15, 0]}>
            <cylinderGeometry args={[0.015, 0.015, 0.15, 6]} />
            <meshStandardMaterial color="#8b4513" />
          </mesh>
        </group>
      </group>
    </group>
  )
}
