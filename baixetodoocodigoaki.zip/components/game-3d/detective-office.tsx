"use client"

import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import { RoundedBox, Text } from "@react-three/drei"
import * as THREE from "three"
import type { ClueObject } from "./game-scene"

const CLUE_COLORS = [
  { main: "#ef4444", glow: "#fca5a5" },
  { main: "#3b82f6", glow: "#93c5fd" },
  { main: "#22c55e", glow: "#86efac" },
  { main: "#f59e0b", glow: "#fcd34d" },
  { main: "#8b5cf6", glow: "#c4b5fd" },
  { main: "#ec4899", glow: "#f9a8d4" },
  { main: "#14b8a6", glow: "#5eead4" },
  { main: "#f97316", glow: "#fdba74" },
]

interface ClueBoxProps {
  clue: ClueObject
  colorIndex: number
  isActive: boolean
  onClick: () => void
}

function ClueBox({ clue, colorIndex, isActive, onClick }: ClueBoxProps) {
  const meshRef = useRef<THREE.Mesh>(null)
  const baseY = clue.position[1]
  const colors = CLUE_COLORS[colorIndex % CLUE_COLORS.length]
  
  useFrame((state) => {
    if (meshRef.current) {
      // Floating animation
      meshRef.current.position.y = baseY + Math.sin(state.clock.elapsedTime * 2 + colorIndex) * 0.1
      // Rotation
      meshRef.current.rotation.y += 0.01
    }
  })
  
  return (
    <group position={[clue.position[0], 0, clue.position[2]]}>
      <mesh
        ref={meshRef}
        position={[0, baseY, 0]}
        onClick={(e) => {
          e.stopPropagation()
          onClick()
        }}
        castShadow
      >
        <boxGeometry args={[0.7, 0.7, 0.7]} />
        <meshStandardMaterial 
          color={colors.main}
          emissive={isActive ? colors.glow : colors.main}
          emissiveIntensity={isActive ? 0.5 : 0.2}
        />
      </mesh>
      
      {/* Label */}
      {isActive && (
        <>
          <Text
            position={[0, baseY + 1.0, 0]}
            fontSize={0.25}
            color="#ffffff"
            anchorX="center"
            anchorY="middle"
            font="/fonts/Geist-Bold.ttf"
          >
            {clue.label}
          </Text>
          <Text
            position={[0, baseY + 0.7, 0]}
            fontSize={0.15}
            color="#22c55e"
            anchorX="center"
            anchorY="middle"
            font="/fonts/Geist-Regular.ttf"
          >
            Pressione E
          </Text>
        </>
      )}
      
      {/* Ground glow */}
      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.8, 16]} />
        <meshBasicMaterial 
          color={colors.main} 
          transparent 
          opacity={isActive ? 0.4 : 0.15} 
        />
      </mesh>
      
      {/* Point light for active */}
      {isActive && (
        <pointLight position={[0, baseY + 0.5, 0]} intensity={0.6} color={colors.glow} distance={3} />
      )}
    </group>
  )
}

// Simplified floor
function Floor() {
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]} receiveShadow>
      <planeGeometry args={[20, 20]} />
      <meshStandardMaterial color="#252535" />
    </mesh>
  )
}

// Simplified walls
function Walls() {
  return (
    <>
      <mesh position={[0, 2.5, -10]} receiveShadow>
        <boxGeometry args={[20, 5, 0.2]} />
        <meshStandardMaterial color="#1a1a28" />
      </mesh>
      <mesh position={[-10, 2.5, 0]} rotation={[0, Math.PI / 2, 0]} receiveShadow>
        <boxGeometry args={[20, 5, 0.2]} />
        <meshStandardMaterial color="#161624" />
      </mesh>
      <mesh position={[10, 2.5, 0]} rotation={[0, -Math.PI / 2, 0]} receiveShadow>
        <boxGeometry args={[20, 5, 0.2]} />
        <meshStandardMaterial color="#161624" />
      </mesh>
    </>
  )
}

// Simple desk
function Desk({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <RoundedBox args={[2.5, 0.12, 1.2]} radius={0.02} position={[0, 0.9, 0]} castShadow>
        <meshStandardMaterial color="#5c3d2e" />
      </RoundedBox>
      {[[-1, 0.45, -0.4], [1, 0.45, -0.4], [-1, 0.45, 0.4], [1, 0.45, 0.4]].map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]} castShadow>
          <boxGeometry args={[0.08, 0.9, 0.08]} />
          <meshStandardMaterial color="#3d2517" />
        </mesh>
      ))}
    </group>
  )
}

// Simple monitor
function Monitor({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 0.4, 0]} castShadow>
        <boxGeometry args={[0.8, 0.55, 0.04]} />
        <meshStandardMaterial color="#1e293b" />
      </mesh>
      <mesh position={[0, 0.4, 0.025]}>
        <planeGeometry args={[0.7, 0.45]} />
        <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={0.2} />
      </mesh>
      <mesh position={[0, 0.08, 0]} castShadow>
        <boxGeometry args={[0.08, 0.16, 0.08]} />
        <meshStandardMaterial color="#374151" />
      </mesh>
      <mesh position={[0, 0, 0]} castShadow>
        <boxGeometry args={[0.3, 0.03, 0.2]} />
        <meshStandardMaterial color="#374151" />
      </mesh>
    </group>
  )
}

// Simple bookshelf
function Bookshelf({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh castShadow>
        <boxGeometry args={[1.5, 2.5, 0.35]} />
        <meshStandardMaterial color="#5c3d2e" />
      </mesh>
      {[-0.6, 0, 0.6].map((y, i) => (
        <mesh key={i} position={[0, y, 0.05]} castShadow>
          <boxGeometry args={[1.4, 0.08, 0.3]} />
          <meshStandardMaterial color="#3d2517" />
        </mesh>
      ))}
      <group position={[0, -0.3, 0.08]}>
        {[
          { x: -0.45, color: "#ef4444", h: 0.4 },
          { x: -0.15, color: "#3b82f6", h: 0.5 },
          { x: 0.15, color: "#22c55e", h: 0.35 },
          { x: 0.45, color: "#f59e0b", h: 0.45 },
        ].map((book, i) => (
          <mesh key={i} position={[book.x, book.h / 2, 0]} castShadow>
            <boxGeometry args={[0.15, book.h, 0.2]} />
            <meshStandardMaterial color={book.color} />
          </mesh>
        ))}
      </group>
    </group>
  )
}

// Evidence board
function EvidenceBoard({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh castShadow>
        <boxGeometry args={[2, 1.4, 0.08]} />
        <meshStandardMaterial color="#3d2517" />
      </mesh>
      <mesh position={[0, 0, 0.05]}>
        <boxGeometry args={[1.85, 1.25, 0.04]} />
        <meshStandardMaterial color="#c4a35a" />
      </mesh>
      {[
        { x: -0.5, y: 0.3, color: "#fef08a" },
        { x: 0.4, y: 0.35, color: "#bfdbfe" },
        { x: -0.3, y: -0.25, color: "#fecaca" },
        { x: 0.5, y: -0.3, color: "#bbf7d0" },
      ].map((note, i) => (
        <mesh key={i} position={[note.x, note.y, 0.08]} rotation={[0, 0, (i - 1.5) * 0.1]}>
          <planeGeometry args={[0.3, 0.3]} />
          <meshStandardMaterial color={note.color} />
        </mesh>
      ))}
    </group>
  )
}

// Lamp with light
function Lamp({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 0.04, 0]} castShadow>
        <cylinderGeometry args={[0.15, 0.18, 0.08, 10]} />
        <meshStandardMaterial color="#1e293b" metalness={0.6} />
      </mesh>
      <mesh position={[0, 0.35, 0]} castShadow>
        <cylinderGeometry args={[0.02, 0.02, 0.55, 6]} />
        <meshStandardMaterial color="#374151" metalness={0.5} />
      </mesh>
      <mesh position={[0, 0.68, 0]} castShadow>
        <coneGeometry args={[0.18, 0.22, 10, 1, true]} />
        <meshStandardMaterial color="#22c55e" side={THREE.DoubleSide} />
      </mesh>
      <pointLight position={[0, 0.58, 0]} intensity={0.6} color="#fef3c7" distance={3} castShadow />
    </group>
  )
}

// Simple chair
function Chair({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh position={[0, 0.4, 0]} castShadow>
        <boxGeometry args={[0.5, 0.08, 0.5]} />
        <meshStandardMaterial color="#1e293b" />
      </mesh>
      <mesh position={[0, 0.75, -0.2]} castShadow>
        <boxGeometry args={[0.5, 0.7, 0.08]} />
        <meshStandardMaterial color="#1e293b" />
      </mesh>
      {[[-0.2, 0.18, -0.2], [0.2, 0.18, -0.2], [-0.2, 0.18, 0.2], [0.2, 0.18, 0.2]].map((pos, i) => (
        <mesh key={i} position={pos as [number, number, number]} castShadow>
          <boxGeometry args={[0.04, 0.36, 0.04]} />
          <meshStandardMaterial color="#374151" />
        </mesh>
      ))}
    </group>
  )
}

// Filing cabinet
function Cabinet({ position }: { position: [number, number, number] }) {
  return (
    <group position={position}>
      <mesh castShadow>
        <boxGeometry args={[0.6, 1.2, 0.5]} />
        <meshStandardMaterial color="#374151" metalness={0.3} />
      </mesh>
      {[0.35, 0, -0.35].map((y, i) => (
        <group key={i} position={[0, y, 0.26]}>
          <mesh>
            <boxGeometry args={[0.5, 0.3, 0.02]} />
            <meshStandardMaterial color="#1e293b" />
          </mesh>
          <mesh position={[0, 0, 0.015]}>
            <boxGeometry args={[0.1, 0.04, 0.02]} />
            <meshStandardMaterial color="#94a3b8" metalness={0.7} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

interface DetectiveOfficeProps {
  activeClueId: string | null
  clues: ClueObject[]
  onClueClick: (clueId: string) => void
}

export function DetectiveOffice({ activeClueId, clues, onClueClick }: DetectiveOfficeProps) {
  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.35} />
      <directionalLight
        position={[5, 8, 5]}
        intensity={0.4}
        castShadow
        shadow-mapSize-width={512}
        shadow-mapSize-height={512}
        shadow-camera-far={25}
        shadow-camera-left={-10}
        shadow-camera-right={10}
        shadow-camera-top={10}
        shadow-camera-bottom={-10}
      />
      
      {/* Room */}
      <Floor />
      <Walls />
      
      {/* Furniture */}
      <Desk position={[0, 0, -6]} />
      <Monitor position={[0, 1, -6]} />
      <Chair position={[0, 0, -4]} />
      <Lamp position={[1, 1, -6]} />
      <Bookshelf position={[-8, 1.25, -5]} />
      <Bookshelf position={[8, 1.25, -5]} />
      <Cabinet position={[-8, 0.6, 2]} />
      <Cabinet position={[8, 0.6, 2]} />
      <EvidenceBoard position={[0, 3, -9.85]} />
      
      {/* Clues */}
      {clues.map((clue, index) => (
        <ClueBox
          key={clue.id}
          clue={clue}
          colorIndex={index}
          isActive={activeClueId === clue.id}
          onClick={() => onClueClick(clue.id)}
        />
      ))}
    </>
  )
}
