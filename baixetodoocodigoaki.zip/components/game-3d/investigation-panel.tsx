"use client"

import { useState, useEffect } from "react"
import { X, CheckCircle2, XCircle, AlertTriangle, Newspaper } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import type { Question } from "@/lib/game-data"

interface InvestigationPanelProps {
  question: Question
  onAnswer: (isCorrect: boolean) => void
  onClose: () => void
}

export function InvestigationPanel({ question, onAnswer, onClose }: InvestigationPanelProps) {
  const [answered, setAnswered] = useState(false)
  const [selectedAnswer, setSelectedAnswer] = useState<boolean | null>(null)
  const [isCorrect, setIsCorrect] = useState(false)
  const [showPanel, setShowPanel] = useState(false)
  
  useEffect(() => {
    setShowPanel(true)
  }, [])
  
  const handleAnswer = (isFake: boolean) => {
    const correct = isFake === question.isFake
    setSelectedAnswer(isFake)
    setIsCorrect(correct)
    setAnswered(true)
  }
  
  const handleContinue = () => {
    onAnswer(isCorrect)
  }
  
  return (
    <div className="absolute inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <Card className={`bg-slate-900 border-slate-700 w-full max-w-2xl max-h-[90vh] overflow-y-auto transition-all duration-300 ${showPanel ? "opacity-100 scale-100" : "opacity-0 scale-95"}`}>
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-yellow-500/20 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4 text-yellow-400" />
            </div>
            <span className="font-bold text-white">Investigacao</span>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose} className="text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </Button>
        </div>
        
        {/* Content */}
        <div className="p-6">
          {!answered ? (
            <>
              {/* News card */}
              <div className="bg-slate-800 rounded-lg p-6 mb-6 border border-slate-700">
                <div className="flex items-center gap-2 mb-4">
                  <Newspaper className="w-5 h-5 text-blue-400" />
                  <span className="text-sm text-slate-400">Noticia encontrada</span>
                </div>
                
                <h3 className="text-xl font-bold text-white mb-4">{question.title}</h3>
                
                <p className="text-slate-300 leading-relaxed">{question.content}</p>
              </div>
              
              {/* Question */}
              <div className="space-y-4">
                <p className="text-center text-slate-300 font-medium">Qual e o seu veredito, detetive?</p>
                
                <div className="grid grid-cols-2 gap-4">
                  <Button
                    onClick={() => handleAnswer(false)}
                    className="h-16 bg-green-600 hover:bg-green-500 text-white font-bold text-lg transition-all hover:scale-[1.02] active:scale-100"
                  >
                    <CheckCircle2 className="w-6 h-6 mr-2" />
                    Verdade
                  </Button>
                  
                  <Button
                    onClick={() => handleAnswer(true)}
                    className="h-16 bg-red-600 hover:bg-red-500 text-white font-bold text-lg transition-all hover:scale-[1.02] active:scale-100"
                  >
                    <XCircle className="w-6 h-6 mr-2" />
                    Fake News
                  </Button>
                </div>
                
                <p className="text-center text-xs text-slate-500">Pressione ESC para voltar sem responder</p>
              </div>
            </>
          ) : (
            <>
              {/* Result */}
              <div className={`rounded-lg p-6 mb-6 ${isCorrect ? "bg-green-900/30 border border-green-700" : "bg-red-900/30 border border-red-700"}`}>
                <div className="flex items-center gap-3 mb-4">
                  {isCorrect ? (
                    <>
                      <div className="w-14 h-14 rounded-full bg-green-500 flex items-center justify-center animate-bounce">
                        <CheckCircle2 className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-green-400">Correto!</h3>
                        <p className="text-green-300">+10 pontos</p>
                      </div>
                    </>
                  ) : (
                    <>
                      <div className="w-14 h-14 rounded-full bg-red-500 flex items-center justify-center">
                        <XCircle className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <h3 className="text-2xl font-bold text-red-400">Incorreto</h3>
                        <p className="text-red-300">Mas voce aprendeu algo novo!</p>
                      </div>
                    </>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-400">A noticia era:</span>
                  <span className={`font-bold text-lg ${question.isFake ? "text-red-400" : "text-green-400"}`}>
                    {question.isFake ? "FAKE NEWS" : "VERDADEIRA"}
                  </span>
                </div>
              </div>
              
              {/* Explanation */}
              <div className="bg-slate-800 rounded-lg p-6 mb-6 border border-slate-700">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-5 h-5 text-yellow-400" />
                  <span className="font-semibold text-white">Explicacao</span>
                </div>
                <p className="text-slate-300 leading-relaxed">{question.explanation}</p>
              </div>
              
              {/* Continue button */}
              <Button
                onClick={handleContinue}
                className="w-full h-14 bg-blue-600 hover:bg-blue-500 text-white font-bold text-lg transition-all hover:scale-[1.01]"
              >
                Continuar Investigacao
              </Button>
            </>
          )}
        </div>
      </Card>
    </div>
  )
}
