"use client"

import { useEffect, useState } from "react"
import { Trophy, Star, Target, RotateCcw, Award, CheckCircle2, XCircle, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"

interface ResultScreen3DProps {
  score: number
  correctAnswers: number
  totalQuestions: number
  onRestart: () => void
}

export function ResultScreen3D({ score, correctAnswers, totalQuestions, onRestart }: ResultScreen3DProps) {
  const [showContent, setShowContent] = useState(false)
  const [showStats, setShowStats] = useState(false)
  const [showButtons, setShowButtons] = useState(false)
  const [animatedScore, setAnimatedScore] = useState(0)
  
  const percentage = totalQuestions > 0 ? Math.round((correctAnswers / totalQuestions) * 100) : 0
  const incorrectAnswers = totalQuestions - correctAnswers
  
  const getStars = () => {
    if (percentage >= 90) return 3
    if (percentage >= 60) return 2
    if (percentage >= 30) return 1
    return 0
  }
  
  const stars = getStars()
  
  const getRank = () => {
    if (stars === 3) return { title: "Detetive Mestre", color: "text-yellow-400", bg: "bg-yellow-500/20" }
    if (stars === 2) return { title: "Detetive Experiente", color: "text-blue-400", bg: "bg-blue-500/20" }
    if (stars === 1) return { title: "Detetive Iniciante", color: "text-green-400", bg: "bg-green-500/20" }
    return { title: "Aprendiz", color: "text-slate-400", bg: "bg-slate-500/20" }
  }
  
  const rank = getRank()
  
  const getMessage = () => {
    if (stars === 3) return "Incrivel! Voce domina a arte de identificar fake news!"
    if (stars === 2) return "Muito bem! Continue praticando para se tornar um mestre!"
    if (stars === 1) return "Bom comeco! Com mais pratica voce ficara ainda melhor!"
    return "Nao desista! Cada erro e uma oportunidade de aprender!"
  }
  
  // Animations sequence
  useEffect(() => {
    const t1 = setTimeout(() => setShowContent(true), 300)
    const t2 = setTimeout(() => setShowStats(true), 800)
    const t3 = setTimeout(() => setShowButtons(true), 1300)
    
    return () => {
      clearTimeout(t1)
      clearTimeout(t2)
      clearTimeout(t3)
    }
  }, [])
  
  // Animate score counter
  useEffect(() => {
    if (!showStats) return
    
    const duration = 1500
    const steps = 30
    const increment = score / steps
    let current = 0
    
    const interval = setInterval(() => {
      current += increment
      if (current >= score) {
        setAnimatedScore(score)
        clearInterval(interval)
      } else {
        setAnimatedScore(Math.floor(current))
      }
    }, duration / steps)
    
    return () => clearInterval(interval)
  }, [showStats, score])
  
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4 overflow-hidden">
      {/* Background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {stars >= 2 && [...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-yellow-400 rounded-full animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 2}s`,
              opacity: 0.3 + Math.random() * 0.5,
            }}
          />
        ))}
      </div>
      
      <div className="w-full max-w-lg relative z-10">
        {/* Trophy and title */}
        <div className={`text-center mb-6 transition-all duration-700 ${showContent ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-10"}`}>
          <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${rank.bg} mb-4 relative`}>
            <Trophy className={`w-12 h-12 ${rank.color}`} />
            {stars === 3 && (
              <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-yellow-400 animate-pulse" />
            )}
          </div>
          
          <h1 className="text-3xl font-bold text-white mb-2">Investigacao Completa!</h1>
          
          <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full ${rank.bg} mb-3`}>
            <Award className={`w-5 h-5 ${rank.color}`} />
            <span className={`font-bold ${rank.color}`}>{rank.title}</span>
          </div>
          
          <p className="text-slate-400 max-w-sm mx-auto">{getMessage()}</p>
        </div>
        
        {/* Stars */}
        <div className={`flex justify-center gap-3 mb-8 transition-all duration-700 delay-200 ${showContent ? "opacity-100 scale-100" : "opacity-0 scale-50"}`}>
          {[1, 2, 3].map((i) => (
            <div
              key={i}
              className={`transition-all duration-500`}
              style={{ transitionDelay: `${i * 150 + 500}ms` }}
            >
              <Star
                className={`w-14 h-14 transition-all duration-500 ${
                  i <= stars 
                    ? "text-yellow-400 fill-yellow-400 drop-shadow-lg" 
                    : "text-slate-700"
                }`}
              />
            </div>
          ))}
        </div>
        
        {/* Stats */}
        <Card className={`bg-slate-800/80 border-slate-700 p-6 mb-6 transition-all duration-700 ${showStats ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          {/* Score display */}
          <div className="text-center mb-6">
            <p className="text-slate-400 text-sm mb-1">Pontuacao Total</p>
            <p className="text-5xl font-bold text-white">{animatedScore}</p>
          </div>
          
          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-4 mb-6">
            <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                </div>
                <div>
                  <p className="text-xs text-green-400">Acertos</p>
                  <p className="text-2xl font-bold text-white">{correctAnswers}</p>
                </div>
              </div>
            </div>
            
            <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-red-500/20 flex items-center justify-center">
                  <XCircle className="w-5 h-5 text-red-400" />
                </div>
                <div>
                  <p className="text-xs text-red-400">Erros</p>
                  <p className="text-2xl font-bold text-white">{incorrectAnswers}</p>
                </div>
              </div>
            </div>
          </div>
          
          {/* Progress bar */}
          <div>
            <div className="flex justify-between text-sm mb-2">
              <span className="text-slate-400">Taxa de acerto</span>
              <span className="text-white font-bold">{percentage}%</span>
            </div>
            <div className="h-3 bg-slate-900 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-green-600 to-green-400 rounded-full transition-all duration-1000 ease-out"
                style={{ width: showStats ? `${percentage}%` : "0%" }}
              />
            </div>
          </div>
        </Card>
        
        {/* Tip card */}
        <Card className={`bg-blue-500/10 border-blue-500/30 p-4 mb-6 transition-all duration-700 ${showStats ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          <div className="flex items-start gap-3">
            <Target className="w-5 h-5 text-blue-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-medium text-blue-400 mb-1">Dica de Detetive</p>
              <p className="text-xs text-slate-300">
                {stars === 3 
                  ? "Compartilhe seu conhecimento! Ensine amigos e familiares a identificar fake news."
                  : "Sempre verifique a fonte da noticia e procure confirmar em outros sites confiaveis antes de acreditar ou compartilhar."
                }
              </p>
            </div>
          </div>
        </Card>
        
        {/* Actions */}
        <div className={`flex flex-col gap-3 transition-all duration-700 ${showButtons ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}>
          <Button
            onClick={onRestart}
            className="w-full h-14 bg-green-600 hover:bg-green-500 text-white font-bold text-lg transition-transform hover:scale-[1.02]"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Jogar Novamente
          </Button>
          
          <Link href="/admin" className="w-full">
            <Button
              variant="outline"
              className="w-full h-12 border-slate-600 text-slate-300 hover:bg-slate-700 hover:text-white"
            >
              Gerenciar Perguntas
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
