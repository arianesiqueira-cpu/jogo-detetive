"use client"

import { useState, useEffect, useCallback, Suspense, useRef } from "react"
import { Canvas } from "@react-three/fiber"
import { DetectiveOffice } from "./detective-office"
import { PlayerController } from "./player-controller"
import { GameHUD } from "./game-hud"
import { InvestigationPanel } from "./investigation-panel"
import { StartScreen3D } from "./start-screen-3d"
import { ResultScreen3D } from "./result-screen-3d"
import { getQuestions, type Question } from "@/lib/game-data"
import { Preload } from "@react-three/drei"

type GameState = "start" | "playing" | "investigating" | "result"

export interface ClueObject {
  id: string
  position: [number, number, number]
  label: string
  questionId: string
  completed: boolean
}

function LoadingScreen() {
  return (
    <div className="absolute inset-0 bg-slate-900 flex items-center justify-center z-50">
      <div className="text-center">
        <div className="w-16 h-16 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-white font-semibold">Carregando escritório...</p>
      </div>
    </div>
  )
}

export function GameScene() {
  const [gameState, setGameState] = useState<GameState>("start")
  const [questions, setQuestions] = useState<Question[]>([])
  const [score, setScore] = useState(0)
  const [correctAnswers, setCorrectAnswers] = useState(0)
  const [activeClueId, setActiveClueId] = useState<string | null>(null)
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null)
  const [clues, setClues] = useState<ClueObject[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const containerRef = useRef<HTMLDivElement>(null)
  
  // Load questions and create clues
  useEffect(() => {
    const loadedQuestions = getQuestions()
    setQuestions(loadedQuestions)
    
    // Fixed positions around the room - easier to find
    const positions: [number, number, number][] = [
      [-5, 0.6, -6],   // Near left bookshelf
      [0, 0.6, -7],    // In front of desk
      [5, 0.6, -6],    // Near right cabinet
      [-6, 0.6, 0],    // Left side
      [6, 0.6, 0],     // Right side
      [-4, 0.6, 4],    // Back left
      [4, 0.6, 4],     // Back right
      [0, 0.6, 5],     // Center back
    ]
    
    const newClues: ClueObject[] = loadedQuestions.slice(0, 8).map((q, index) => ({
      id: `clue-${index}`,
      position: positions[index],
      label: `Pista ${index + 1}`,
      questionId: q.id,
      completed: false,
    }))
    
    setClues(newClues)
    setIsLoading(false)
  }, [])
  
  // Handle E key press to interact
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === "KeyE" && gameState === "playing" && activeClueId) {
        const clue = clues.find(c => c.id === activeClueId)
        if (clue && !clue.completed) {
          const question = questions.find(q => q.id === clue.questionId)
          if (question) {
            setCurrentQuestion(question)
            setGameState("investigating")
          }
        }
      }
      
      if (e.code === "Escape" && gameState === "investigating") {
        setGameState("playing")
        setCurrentQuestion(null)
      }
    }
    
    window.addEventListener("keydown", handleKeyDown)
    return () => window.removeEventListener("keydown", handleKeyDown)
  }, [gameState, activeClueId, clues, questions])
  
  const handleStart = useCallback(() => {
    setGameState("playing")
    setScore(0)
    setCorrectAnswers(0)
    // Reset all clues
    setClues(prev => prev.map(c => ({ ...c, completed: false })))
    // Focus the container to capture keyboard events
    containerRef.current?.focus()
  }, [])
  
  const handleAnswer = useCallback((isCorrect: boolean) => {
    if (currentQuestion) {
      if (isCorrect) {
        setScore(s => s + 10)
        setCorrectAnswers(c => c + 1)
      }
      
      // Mark the clue as completed
      setClues(prev => prev.map(c => 
        c.questionId === currentQuestion.id ? { ...c, completed: true } : c
      ))
    }
    
    setCurrentQuestion(null)
    
    // Check if all clues are completed
    const completedCount = clues.filter(c => c.completed).length + 1
    if (completedCount >= clues.length) {
      setTimeout(() => setGameState("result"), 500)
    } else {
      setGameState("playing")
    }
  }, [currentQuestion, clues])
  
  const handleRestart = useCallback(() => {
    setGameState("start")
    setScore(0)
    setCorrectAnswers(0)
    setClues(prev => prev.map(c => ({ ...c, completed: false })))
  }, [])
  
  const handleNearClue = useCallback((clueId: string | null) => {
    if (gameState === "playing") {
      setActiveClueId(clueId)
    }
  }, [gameState])
  
  const handleClueClick = useCallback((clueId: string) => {
    const clue = clues.find(c => c.id === clueId)
    if (clue && !clue.completed && gameState === "playing") {
      const question = questions.find(q => q.id === clue.questionId)
      if (question) {
        setCurrentQuestion(question)
        setGameState("investigating")
      }
    }
  }, [clues, questions, gameState])
  
  if (gameState === "start") {
    return <StartScreen3D onStart={handleStart} />
  }
  
  if (gameState === "result") {
    return (
      <ResultScreen3D 
        score={score}
        correctAnswers={correctAnswers}
        totalQuestions={clues.length}
        onRestart={handleRestart}
      />
    )
  }
  
  const activeClues = clues.filter(c => !c.completed)
  const completedCount = clues.filter(c => c.completed).length
  
  return (
    <div 
      ref={containerRef}
      className="relative w-full h-screen bg-slate-900 outline-none"
      tabIndex={0}
    >
      {isLoading && <LoadingScreen />}
      
      <Canvas
        shadows
        camera={{ position: [0, 5, 10], fov: 60 }}
        className="w-full h-full"
        dpr={[1, 1.5]} // Limit pixel ratio for performance
      >
        <Suspense fallback={null}>
          <fog attach="fog" args={["#0f172a", 8, 35]} />
          
          <DetectiveOffice
            activeClueId={activeClueId}
            clues={activeClues}
            onClueClick={handleClueClick}
          />
          
          <PlayerController 
            onNearClue={handleNearClue}
            clues={activeClues}
            enabled={gameState === "playing"}
          />
          
          <Preload all />
        </Suspense>
      </Canvas>
      
      {/* HUD */}
      <GameHUD
        score={score}
        totalClues={clues.length}
        completedClues={completedCount}
        activeClueId={activeClueId}
        showControls={gameState === "playing"}
      />
      
      {/* Investigation panel */}
      {gameState === "investigating" && currentQuestion && (
        <InvestigationPanel
          question={currentQuestion}
          onAnswer={handleAnswer}
          onClose={() => {
            setGameState("playing")
            setCurrentQuestion(null)
          }}
        />
      )}
    </div>
  )
}
