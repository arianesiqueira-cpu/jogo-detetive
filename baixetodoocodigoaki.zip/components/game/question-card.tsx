"use client"

import { CheckCircle, XCircle, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Question } from "@/lib/game-data"

interface QuestionCardProps {
  question: Question
  currentIndex: number
  totalQuestions: number
  onAnswer: (answeredFake: boolean) => void
}

export function QuestionCard({ question, currentIndex, totalQuestions, onAnswer }: QuestionCardProps) {
  const progress = ((currentIndex) / totalQuestions) * 100

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full space-y-6 animate-slide-up">
        {/* Progresso */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-slate-400">
            <span>Caso {currentIndex + 1} de {totalQuestions}</span>
            <span>{Math.round(progress)}% completo</span>
          </div>
          <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-green-500 to-emerald-400 transition-all duration-500 ease-out rounded-full"
              style={{ width: `${progress}%` }}
            />
          </div>
        </div>

        {/* Card da Notícia */}
        <div className="bg-slate-800 rounded-3xl p-8 shadow-2xl border border-slate-700 space-y-6">
          {/* Cabeçalho */}
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-yellow-500/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6 text-yellow-400" />
            </div>
            <div>
              <span className="text-xs uppercase tracking-wider text-slate-500 font-medium">Notícia suspeita</span>
              <h2 className="text-2xl font-bold text-white mt-1">{question.title}</h2>
            </div>
          </div>

          {/* Imagem opcional */}
          {question.image && (
            <div className="rounded-2xl overflow-hidden">
              <img 
                src={question.image} 
                alt={question.title}
                className="w-full h-48 object-cover"
              />
            </div>
          )}

          {/* Conteúdo */}
          <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-700">
            <p className="text-lg text-slate-200 leading-relaxed">
              &quot;{question.content}&quot;
            </p>
          </div>

          {/* Pergunta */}
          <p className="text-center text-slate-400 font-medium">
            Essa notícia é verdadeira ou fake news?
          </p>

          {/* Botões de Resposta */}
          <div className="grid grid-cols-2 gap-4">
            <Button
              onClick={() => onAnswer(false)}
              size="lg"
              className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white text-xl py-8 rounded-2xl shadow-lg shadow-green-500/20 transform hover:scale-105 transition-all duration-200"
            >
              <CheckCircle className="w-7 h-7 mr-3" />
              Verdade
            </Button>
            <Button
              onClick={() => onAnswer(true)}
              size="lg"
              className="bg-gradient-to-r from-red-500 to-rose-600 hover:from-red-600 hover:to-rose-700 text-white text-xl py-8 rounded-2xl shadow-lg shadow-red-500/20 transform hover:scale-105 transition-all duration-200"
            >
              <XCircle className="w-7 h-7 mr-3" />
              Fake News
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
