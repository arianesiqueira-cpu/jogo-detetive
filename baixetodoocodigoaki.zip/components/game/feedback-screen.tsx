"use client"

import { CheckCircle, XCircle, Lightbulb, ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import type { Question } from "@/lib/game-data"

interface FeedbackScreenProps {
  question: Question
  isCorrect: boolean
  onNext: () => void
  isLastQuestion: boolean
}

export function FeedbackScreen({ question, isCorrect, onNext, isLastQuestion }: FeedbackScreenProps) {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className={`max-w-2xl w-full space-y-6 animate-scale-in`}>
        {/* Resultado */}
        <div className={`rounded-3xl p-8 shadow-2xl border ${
          isCorrect 
            ? 'bg-green-500/10 border-green-500/30' 
            : 'bg-red-500/10 border-red-500/30'
        }`}>
          {/* Ícone e Mensagem */}
          <div className="text-center space-y-4">
            <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full ${
              isCorrect ? 'bg-green-500/20' : 'bg-red-500/20'
            } animate-bounce-once`}>
              {isCorrect ? (
                <CheckCircle className="w-14 h-14 text-green-400" />
              ) : (
                <XCircle className="w-14 h-14 text-red-400" />
              )}
            </div>
            
            <h2 className={`text-3xl font-bold ${isCorrect ? 'text-green-400' : 'text-red-400'}`}>
              {isCorrect ? 'Muito bem, detetive!' : 'Ops! Não foi dessa vez...'}
            </h2>
            
            <p className="text-lg text-slate-300">
              {isCorrect 
                ? 'Você identificou corretamente!' 
                : 'Mas não desanime, cada erro é uma chance de aprender!'
              }
            </p>
          </div>
        </div>

        {/* Explicação */}
        <div className="bg-slate-800 rounded-3xl p-8 shadow-2xl border border-slate-700 space-y-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-500/20 rounded-xl flex items-center justify-center">
              <Lightbulb className="w-5 h-5 text-yellow-400" />
            </div>
            <h3 className="text-xl font-semibold text-white">Explicação</h3>
          </div>
          
          <div className="bg-slate-900/50 rounded-2xl p-6 border border-slate-700">
            <p className="text-lg text-slate-200 leading-relaxed">
              {question.explanation}
            </p>
          </div>

          <div className="flex items-center gap-2 text-sm">
            <span className="text-slate-400">A notícia era:</span>
            <span className={`font-semibold ${question.isFake ? 'text-red-400' : 'text-green-400'}`}>
              {question.isFake ? '❌ FAKE NEWS' : '✅ VERDADEIRA'}
            </span>
          </div>
        </div>

        {/* Botão Próximo */}
        <Button
          onClick={onNext}
          size="lg"
          className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white text-xl py-8 rounded-2xl shadow-2xl shadow-green-500/30 transform hover:scale-[1.02] transition-all duration-300"
        >
          {isLastQuestion ? 'Ver Resultado Final' : 'Próximo Caso'}
          <ArrowRight className="w-6 h-6 ml-3" />
        </Button>
      </div>
    </div>
  )
}
