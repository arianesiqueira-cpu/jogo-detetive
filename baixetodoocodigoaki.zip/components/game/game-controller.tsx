"use client"

import { useState, useEffect, useCallback } from "react"
import { StartScreen } from "./start-screen"
import { QuestionCard } from "./question-card"
import { FeedbackScreen } from "./feedback-screen"
import { ResultScreen } from "./result-screen"
import { getQuestions, resetGameProgress, type Question } from "@/lib/game-data"

type GameState = "start" | "playing" | "feedback" | "result"

export function GameController() {
  const [gameState, setGameState] = useState<GameState>("start")
  const [questions, setQuestions] = useState<Question[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [score, setScore] = useState(0)
  const [lastAnswerCorrect, setLastAnswerCorrect] = useState(false)

  useEffect(() => {
    setQuestions(getQuestions())
  }, [])

  const startGame = useCallback(() => {
    resetGameProgress()
    setQuestions(getQuestions())
    setCurrentIndex(0)
    setScore(0)
    setGameState("playing")
  }, [])

  const handleAnswer = useCallback((answeredFake: boolean) => {
    const currentQuestion = questions[currentIndex]
    const isCorrect = answeredFake === currentQuestion.isFake
    
    if (isCorrect) {
      setScore(prev => prev + 1)
    }
    
    setLastAnswerCorrect(isCorrect)
    setGameState("feedback")
  }, [questions, currentIndex])

  const handleNext = useCallback(() => {
    if (currentIndex + 1 >= questions.length) {
      setGameState("result")
    } else {
      setCurrentIndex(prev => prev + 1)
      setGameState("playing")
    }
  }, [currentIndex, questions.length])

  const goToHome = useCallback(() => {
    setGameState("start")
  }, [])

  if (questions.length === 0) {
    return (
      <div className="min-h-screen bg-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Carregando...</div>
      </div>
    )
  }

  switch (gameState) {
    case "start":
      return <StartScreen onStart={startGame} />
    case "playing":
      return (
        <QuestionCard
          question={questions[currentIndex]}
          currentIndex={currentIndex}
          totalQuestions={questions.length}
          onAnswer={handleAnswer}
        />
      )
    case "feedback":
      return (
        <FeedbackScreen
          question={questions[currentIndex]}
          isCorrect={lastAnswerCorrect}
          onNext={handleNext}
          isLastQuestion={currentIndex + 1 >= questions.length}
        />
      )
    case "result":
      return (
        <ResultScreen
          score={score}
          totalQuestions={questions.length}
          onRestart={startGame}
          onHome={goToHome}
        />
      )
  }
}
