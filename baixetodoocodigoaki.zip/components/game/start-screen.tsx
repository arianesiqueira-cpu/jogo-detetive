"use client"

import { Search, Shield, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"

interface StartScreenProps {
  onStart: () => void
}

export function StartScreen({ onStart }: StartScreenProps) {
  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center space-y-8 animate-fade-in">
        {/* Logo e Título */}
        <div className="space-y-4">
          <div className="flex justify-center">
            <div className="relative">
              <div className="w-32 h-32 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center shadow-2xl shadow-green-500/30 animate-pulse-slow">
                <Search className="w-16 h-16 text-white" />
              </div>
              <div className="absolute -top-2 -right-2 w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center shadow-lg animate-bounce-slow">
                <AlertTriangle className="w-6 h-6 text-yellow-900" />
              </div>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-6xl font-bold text-white tracking-tight">
            Detetive da <span className="text-green-400">Verdade</span>
          </h1>
          
          <p className="text-xl text-slate-300 max-w-md mx-auto leading-relaxed">
            Você consegue identificar o que é <span className="text-green-400 font-semibold">verdade</span> e o que é <span className="text-red-400 font-semibold">fake news</span>?
          </p>
        </div>

        {/* Instruções */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-2xl p-6 space-y-4 border border-slate-700">
          <h2 className="text-lg font-semibold text-white flex items-center justify-center gap-2">
            <Shield className="w-5 h-5 text-green-400" />
            Como jogar
          </h2>
          <div className="grid gap-3 text-left">
            <div className="flex items-start gap-3 text-slate-300">
              <span className="flex-shrink-0 w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center text-green-400 font-bold">1</span>
              <p>Leia cada notícia com atenção</p>
            </div>
            <div className="flex items-start gap-3 text-slate-300">
              <span className="flex-shrink-0 w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center text-green-400 font-bold">2</span>
              <p>Decida se é verdade ou fake news</p>
            </div>
            <div className="flex items-start gap-3 text-slate-300">
              <span className="flex-shrink-0 w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center text-green-400 font-bold">3</span>
              <p>Aprenda com as explicações</p>
            </div>
          </div>
        </div>

        {/* Botão Iniciar */}
        <Button
          onClick={onStart}
          size="lg"
          className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white text-xl px-12 py-8 rounded-2xl shadow-2xl shadow-green-500/30 transform hover:scale-105 transition-all duration-300"
        >
          <Search className="w-6 h-6 mr-3" />
          Começar Investigação
        </Button>

        {/* Link Admin */}
        <a 
          href="/admin" 
          className="text-slate-500 text-sm hover:text-slate-400 transition-colors inline-block"
        >
          Área administrativa
        </a>
      </div>
    </div>
  )
}
