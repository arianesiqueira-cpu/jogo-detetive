"use client"

import { Trophy, Star, RotateCcw, Home } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ResultScreenProps {
  score: number
  totalQuestions: number
  onRestart: () => void
  onHome: () => void
}

export function ResultScreen({ score, totalQuestions, onRestart, onHome }: ResultScreenProps) {
  const percentage = Math.round((score / totalQuestions) * 100)
  
  const getMessage = () => {
    if (percentage === 100) return { title: "Incrível!", subtitle: "Você é um mestre detetive!" }
    if (percentage >= 80) return { title: "Excelente!", subtitle: "Você é quase um especialista!" }
    if (percentage >= 60) return { title: "Muito bom!", subtitle: "Continue praticando!" }
    if (percentage >= 40) return { title: "Bom trabalho!", subtitle: "Você está aprendendo!" }
    return { title: "Continue tentando!", subtitle: "A prática leva à perfeição!" }
  }

  const message = getMessage()

  const getStars = () => {
    if (percentage >= 80) return 3
    if (percentage >= 50) return 2
    return 1
  }

  return (
    <div className="min-h-screen bg-slate-900 flex items-center justify-center p-4">
      <div className="max-w-2xl w-full text-center space-y-8 animate-fade-in">
        {/* Troféu */}
        <div className="relative inline-block">
          <div className="w-32 h-32 bg-gradient-to-br from-yellow-400 to-amber-500 rounded-full flex items-center justify-center shadow-2xl shadow-yellow-500/30 animate-pulse-slow">
            <Trophy className="w-16 h-16 text-white" />
          </div>
          <div className="absolute -top-4 left-1/2 -translate-x-1/2 flex gap-1">
            {Array.from({ length: getStars() }).map((_, i) => (
              <Star 
                key={i} 
                className="w-8 h-8 text-yellow-400 fill-yellow-400 animate-bounce-slow" 
                style={{ animationDelay: `${i * 0.1}s` }}
              />
            ))}
          </div>
        </div>

        {/* Mensagem */}
        <div className="space-y-2">
          <h1 className="text-5xl font-bold text-white">{message.title}</h1>
          <p className="text-xl text-slate-300">{message.subtitle}</p>
        </div>

        {/* Pontuação */}
        <div className="bg-slate-800/50 backdrop-blur-sm rounded-3xl p-8 border border-slate-700 space-y-6">
          <div className="text-center">
            <span className="text-slate-400 text-lg">Sua pontuação</span>
            <div className="text-7xl font-bold text-green-400 mt-2">
              {score}/{totalQuestions}
            </div>
            <span className="text-2xl text-slate-400">{percentage}% de acertos</span>
          </div>

          {/* Barra de Progresso */}
          <div className="space-y-2">
            <div className="h-4 bg-slate-700 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-green-500 to-emerald-400 rounded-full transition-all duration-1000 ease-out"
                style={{ width: `${percentage}%` }}
              />
            </div>
          </div>

          {/* Estatísticas */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-green-500/10 rounded-2xl p-4 border border-green-500/20">
              <span className="text-3xl font-bold text-green-400">{score}</span>
              <p className="text-sm text-slate-400">Acertos</p>
            </div>
            <div className="bg-red-500/10 rounded-2xl p-4 border border-red-500/20">
              <span className="text-3xl font-bold text-red-400">{totalQuestions - score}</span>
              <p className="text-sm text-slate-400">Erros</p>
            </div>
          </div>
        </div>

        {/* Botões */}
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            onClick={onRestart}
            size="lg"
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 text-white text-lg px-8 py-6 rounded-2xl shadow-lg shadow-green-500/20 transform hover:scale-105 transition-all duration-200"
          >
            <RotateCcw className="w-5 h-5 mr-2" />
            Jogar Novamente
          </Button>
          <Button
            onClick={onHome}
            size="lg"
            variant="outline"
            className="border-slate-600 text-slate-300 hover:bg-slate-800 text-lg px-8 py-6 rounded-2xl transform hover:scale-105 transition-all duration-200"
          >
            <Home className="w-5 h-5 mr-2" />
            Início
          </Button>
        </div>
      </div>
    </div>
  )
}
